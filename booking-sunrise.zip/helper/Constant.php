<?php
define("HOST", "localhost");
define("UNAME", "root");
define("PASS", "");
define("DB", "sunriseindonesia_7");

define('SUCCESS', 'success');
define('FAIL', 'failed');
// $con = mysqli_connect("localhost","sunriseindonesia_7","13h-p.S14c","sunriseindonesia_7");
