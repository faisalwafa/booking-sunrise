<?php

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once '../inc/header.php'; ?>
    <title>Lupa Password | Sunrise Indonesia</title>
</head>

<body class="min-vh-100 bg-light">
    <div class="container min-vh-100">
        <div class="card">
            <div class="card-body">
                <form>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" readonly class="form-control-plaintext" id="email" value="email@example.com">
                    </div>
                    <div class="form-group">
                        <label for="register-password">Password</label>
                        <input type="password" class="form-control" id="register-password" class="form-control" onfocusout="checkRegisterPassword()">
                        <small class="invalid-feedback" id="register-password-feedback">Password tidak boleh kosong</small>
                    </div>
                    <div class="form-group">
                        <label for="register-passwordConfirm">Konfirmasi Password</label>
                        <input type="password" class="form-control" id="register-passwordConfirm" class="form-control" onfocusout="checkRegisterPasswordConfirm()" onkeyup="checkRegisterPasswordConfirm()">
                        <div class="invalid-feedback">
                            Password tidak cocok
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php include_once '../inc/scripts.php'; ?>
</body>

</html>